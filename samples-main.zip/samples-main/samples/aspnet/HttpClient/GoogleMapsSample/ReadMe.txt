GoogleMapsSample
----------------

This sample uses HttpClient to download a map of Redmond, WA from Google Maps, saves it as a 
local file, and opens the default image viewer.

For a detailed description of this sample, please see
http://blogs.msdn.com/b/henrikn/archive/2012/02/17/downloading-a-google-map-to-local-file.aspx
